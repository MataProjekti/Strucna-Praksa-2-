// api.memegen.link - besplatan open-source meme API (MIT licenca)
// Format: https://api.memegen.link/images/{template}/{top_text}/{bottom_text}.png

const memes = [
  {
    template: "doge",
    top: "such code",
    bottom: "much bug",
    caption: "Doge programer"
  },
  {
    template: "buzz",
    top: "memes memes",
    bottom: "memes everywhere",
    caption: "Buzz Lightyear – memovi svuda"
  },
  {
    template: "fry",
    top: "not sure if bug",
    bottom: "or just a feature",
    caption: "Futurama Fry"
  },
  {
    template: "drake",
    top: "writing tests",
    bottom: "pushing to prod and praying",
    caption: "Drake bira"
  },
  {
    template: "oprah",
    top: "you get a bug",
    bottom: "and you get a bug",
    caption: "Oprah deli bagove"
  },
  {
    template: "two-buttons",
    top: "fix the bug",
    bottom: "create 3 new bugs",
    caption: "Dva dugmeta dilema"
  },
  {
    template: "disloyal-boyfriend",
    top: "stackoverflow",
    bottom: "my own documentation",
    caption: "Neverni momak – Stack Overflow"
  },
  {
    template: "stonks",
    top: "copy paste from stackoverflow",
    bottom: "stonks",
    caption: "Stonks programer"
  },
  {
    template: "disaster-girl",
    top: "production server",
    bottom: "me after one small change",
    caption: "Devojčica i požar"
  },
  {
    template: "this-is-fine",
    top: "production is on fire",
    bottom: "this is fine",
    caption: "This is fine"
  },
];

const jokes = [
  { setup: "Zašto programeri ne vole prirodu?", punchline: "Previše bagova (bugs)! 🐛" },
  { setup: "Kako se zove programer koji ne testira kod?", punchline: "Optimista. 🤞" },
  { setup: "Šta je HTTP status 418?", punchline: "I'm a teapot – server odbija da skuva kafu! ☕" },
  { setup: "Zašto je Java programer nosio naočare?", punchline: "Jer nije video Sharp (C#). 👓" },
  { setup: "Koliko programera treba da se zameni sijalica?", punchline: "Nula – to je problem hardvera. 💡" },
  { setup: "Šta je rekao jedan bit drugom?", punchline: "Mogu da te razumem na svakom nivou. 🤝" },
  { setup: "Zašto je baza podataka otišla na terapiju?", punchline: "Imala je previše odnosa (relations). 🛋️" },
  { setup: "Koji je omiljeni muzički žanr programera?", punchline: "Algo-ritam! 🎵" },
  { setup: "Šta kaže programer kad se probudi?", punchline: "Hello, World! 🌍" },
  { setup: "Rekurzija je...", punchline: "...pogledaj: Rekurzija je. 🔄" },
  { setup: "Zašto je programer ostavio posao?", punchline: "Jer nije dobio raises, samo exceptions. 📈" },
  { setup: "Šta je najopasnija rečenica u IT-u?", punchline: "\"Samo brza izmena, neće mi trebati ni 5 minuta.\" ⏱️" },
];

const quotes = [
  { text: "Svaki dovoljan napredak izgleda kao magija.", author: "Arthur C. Clarke" },
  { text: "Debugging je dva puta teže od pisanja koda. Ako pišeš najkompleksniji kod koji možeš, po definiciji nisi dovoljno pametan da ga debuguješ.", author: "Brian W. Kernighan" },
  { text: "Svaki veliki developer jednom je bio početnik.", author: "Carol Dweck" },
  { text: "Jednostavnost je najveća sofisticiranost.", author: "Leonardo da Vinci" },
  { text: "Ako ne možeš da objasniš detetu, nisi dovoljno dobro razumeo.", author: "Albert Einstein" },
  { text: "Kod koji nisi napisao ne treba da se održava.", author: "Jeff Atwood" },
  { text: "Greška je dokaz da pokušavaš.", author: "Nepoznat" },
  { text: "Prvo reši problem, pa onda piši kod.", author: "John Johnson" },
  { text: "Svaki program ima bar još jedan bag.", author: "Lubarsky" },
  { text: "Programiranje je umetnost govora tačno šta hoćeš da se desi.", author: "Donald Knuth" },
];

const riddles = [
  { q: "Imam gradove, ali nema kuća. Imam planine, ali nema drveća. Imam vodu, ali nema ribe. Ko sam ja?", a: "Mapa / karta 🗺️" },
  { q: "Što više uzimeš, više ga ostaviš iza sebe. Šta je to?", a: "Koraci (tragovi) 👣" },
  { q: "Govori bez usta i čuje bez ušiju. Nema tela, ali drhti na vetru. Šta je to?", a: "Eho 🗣️" },
  { q: "Šta uvek ide napred, ali nikada ne stigne?", a: "Sutrašnji dan 📅" },
  { q: "Ima ključ ali nema bravu. Ima prostor ali nema soba. Šta je to?", a: "Klavijatura ⌨️" },
  { q: "Siromašan sam bez njega, bogat sam s njim, ali ako ga previše imam – uništen sam. Šta je to?", a: "Novac 💰" },
  { q: "Čim me vidiš, ja nestajam. Šta sam ja?", a: "Tama 🌑" },
  { q: "Može da putuje oko sveta, a ostaje u uglu. Šta je to?", a: "Poštanska markica 📮" },
  { q: "Programer ima 2 problema. Rešio je jedan koristeći regex. Koliko problema sada ima?", a: "3 problema – regex je uvek novi problem! 😅" },
];

let currentRiddle = null;

function rnd(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function setOutput(html) {
  document.getElementById('output').innerHTML = html;
}

function buildMemeUrl(template, top, bottom) {
  const encode = (s) => encodeURIComponent(s.replace(/ /g, '_'));
  return `https://api.memegen.link/images/${template}/${encode(top)}/${encode(bottom)}.png`;
}

function showMeme() {
  const m = rnd(memes);
  const url = buildMemeUrl(m.template, m.top, m.bottom);

  setOutput(`
    <div class="line-category">Programmer memes</div>
    <div class="line-sub">${m.caption}</div>
    <div class="meme-img-wrap">
      <p class="meme-loading" id="meme-status">⏳ Učitavanje mema...</p>
      <img
        src="${url}"
        alt="${m.caption}"
        style="display:none;"
        onload="
          document.getElementById('meme-status').style.display='none';
          this.style.display='block';
        "
        onerror="
          document.getElementById('meme-status').textContent='';
          this.insertAdjacentHTML('afterend','<p class=meme-error>❌ Nije moguće učitati mem. Proveri internet konekciju.</p>');
          this.remove();
        "
      />
    </div>
    <div class="line-sub" style="margin-top:6px; font-size:11px;">
      Izvor: api.memegen.link (MIT licenca, open-source)
    </div>
  `);
}

function tellJoke() {
  const j = rnd(jokes);
  setOutput(`
    <div class="line-category">Tell me something funny!</div>
    <div class="line-main">${j.setup}</div>
    <div class="line-punchline">${j.punchline}</div>
  `);
}

function randomQuote() {
  const q = rnd(quotes);
  setOutput(`
    <div class="line-category">Give me some wisdom...</div>
    <div class="line-main" style="font-style:italic;">"${q.text}"</div>
    <div class="line-author">— ${q.author}</div>
  `);
}

function riddleMe() {
  currentRiddle = rnd(riddles);
  setOutput(`
    <div class="line-category">I want a riddle!</div>
    <div class="line-main">${currentRiddle.q}</div>
    <div class="line-sub" style="margin-top:6px;">Klikni "Reveal Riddle Answer" za odgovor.</div>
  `);
}

function revealAnswer() {
  if (!currentRiddle) {
    setOutput(`<p class="line-sub" style="color:#e06060;">⚠️ Prvo klikni "Riddle me" da dobiješ zagonetku!</p>`);
    return;
  }
  const out = document.getElementById('output');
  const existing = out.querySelector('.line-answer');
  if (existing) {
    existing.remove();
    return;
  }
  const ans = document.createElement('div');
  ans.className = 'line-answer';
  ans.textContent = '✅ Odgovor: ' + currentRiddle.a;
  out.appendChild(ans);
}